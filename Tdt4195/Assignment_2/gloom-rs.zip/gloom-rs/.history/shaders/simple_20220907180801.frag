#version 430 core

varying vec4 v_color;
out vec4 color;

void main()
{
    varying vec4 rand;
    color = vec4(fract(v_color.rgb + time), 1.0f);
}