#version 430 core

in vec3 position;
out float rng_value

void main()
{
    gl_Position = vec4(position, 1.0f);
}