#version 430 core

out vec4 color;

void main()
{
    int n = int(x.x * 40.0 + x.y * 6400.0);
    n = (n << 13) ^ n;
    vec2 x = 1.0 - float( (n * (n * n * 15731 + 789221) + \1376312589) & 0x7fffffff) / 1073741824.0;
    color = vec4(x, x, x, 1.0f);
}