#version 430 core

varying vec4 v_color;
out vec4 color;

void main()
{

    float randInt1 = mod(time, 1000) / 1000;
    float randInt2 = mod(time, 1000) / 1000;
    float randInt3 = mod(time, 1000) / 1000;
    varying rand = vec3(randInt1, randInt1, randInt1);
    color = vec4(fract(v_color.rgb + time), 1.0f);
}