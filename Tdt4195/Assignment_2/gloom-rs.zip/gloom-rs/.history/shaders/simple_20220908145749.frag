#version 430 core

out vec4 color;
uniform float red;
uniform float green;
uniform float blue;

void main()
{
    color = vec4(red, green, blue, 1.0f);
}