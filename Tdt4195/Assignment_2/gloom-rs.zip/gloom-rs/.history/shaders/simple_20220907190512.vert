#version 430 core

in vec3 position;
in float red;
in float green;
in float blue;

void main()
{
    gl_Position = vec4(position, 1.0f);
}