#version 430 core

uniform float time;
out vec4 color;

void main()
{
    color = vec4(sin(time), cos(time), tan(time) 1.0f);
}