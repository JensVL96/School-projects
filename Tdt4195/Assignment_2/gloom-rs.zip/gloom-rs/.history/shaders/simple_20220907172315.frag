#version 430 core

out vec4 color;

void main()
{
    
    vec3 temp = vec3(rand)
    color = vec4(temp, 1.0f);
}