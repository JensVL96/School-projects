#version 430 core

uniform float time;
out vec4 color;

void main()
{
    vec3 inputs = vec3(0, 1, time);
    color = vec4(inputs, 1.0f);
}