#version 430 core

uniform float time;
out vec4 color;

uint hash( uint x ) {
    x += ( x << 10u );
    x ^= ( x >>  6u );
    x += ( x <<  3u );
    x ^= ( x >> 11u );
    x += ( x << 15u );
    return x;
}

void main()
{
    vec3 inputs = 
    float rand = random(inputs);
    vec3 temp = vec3(rand);
    color = vec4(temp, 1.0f);
}