#version 430 core

uniform float time;
out vec4 color;

void main()
{
    float rand = sin(1824) - mod(sin(1824), 0.1);
    color = vec4(rand, rand, rand, 1.0f);
}