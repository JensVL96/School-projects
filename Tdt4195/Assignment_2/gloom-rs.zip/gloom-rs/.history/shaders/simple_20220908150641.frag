#version 430 core

out vec4 color;
uniform layout(layout=0) float red;
uniform layout(layout=0) float green;
uniform layout(layout=0) float blue;

void main()
{
    color = vec4(red, green, blue, 1.0f);
}