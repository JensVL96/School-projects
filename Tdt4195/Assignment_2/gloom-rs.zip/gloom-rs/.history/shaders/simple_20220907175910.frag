#version 430 core

precision mediump float;
uniform float time;
out vec4 color;
varying vec4 v_color;

void main()
{

    float randInt1 = mod(time, 1000) / 1000;
    float randInt2 = mod(time, 1000) / 1000;
    float randInt3 = mod(time, 1000) / 1000;
    vec3 rand = vec3(randInt1, randInt1, randInt1);
    color = vec4(fract(v_color.rgb + time), 1.0f);
}