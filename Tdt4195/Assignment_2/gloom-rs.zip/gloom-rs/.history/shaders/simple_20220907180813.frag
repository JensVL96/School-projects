#version 430 core

varying vec4 v_color;
out vec4 color;

void main()
{
    varying vec3 rand;
    color = vec4(rand, 1.0f);
}