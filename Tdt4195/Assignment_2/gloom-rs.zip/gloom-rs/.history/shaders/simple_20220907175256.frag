#version 430 core

uniform float time;
out vec4 color;

void main()
{

    float randInt1 = mod(time, 1000) / 1000;
    float randInt2 = mod(time, 1000) / 1000;
    float randInt3 = mod(time, 1000) / 1000;
    vec3 rand = vec3(randInt1, randInt1, randInt1);
    color = vec4(rand, 1.0f);
}