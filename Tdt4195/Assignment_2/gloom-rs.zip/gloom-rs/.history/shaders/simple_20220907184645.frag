#version 430 core

out vec4 color;
in float rng_value

void main()
{
    float rand = sin(1824) - mod(sin(1824), 0.1);
    color = vec4(rng_value, rng_value, rng_value, 1.0f);
}