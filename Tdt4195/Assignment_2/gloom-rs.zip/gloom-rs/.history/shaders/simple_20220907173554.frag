#version 430 core

uniform float time;
out vec4 color;

void main()
{
    randInt = mod(time, 1000) / 1000
    vec3 rand = vec3(0, 1, time);
    color = vec4(rand, 1.0f);
}