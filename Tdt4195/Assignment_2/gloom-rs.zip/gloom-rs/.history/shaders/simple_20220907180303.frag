#version 430 core

uniform float m_thresh;
uniform sampler2D grabTexture;

//varying vec2 texCoord;

void main(void)
{
  //vec4  grab   = texture2D (grabTexture, texCoord.st);

  vec4  grab   = texture2D (grabTexture, gl_TexCoord [0].st);
  vec3  colour = grab.xyz * m_thresh;
  gl_FragColor = vec4( colour, 0.5 );
}

precision mediump float;
varying vec4 v_color;
out vec4 color;

void main()
{

    float randInt1 = mod(time, 1000) / 1000;
    float randInt2 = mod(time, 1000) / 1000;
    float randInt3 = mod(time, 1000) / 1000;
    vec3 rand = vec3(randInt1, randInt1, randInt1);
    color = vec4(fract(v_color.rgb + time), 1.0f);
}