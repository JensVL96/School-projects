#version 430 core

out vec4 color;

void main()
{
    varying vec3 rand;
    color = vec4(rand, 1.0f);
}