#version 430 core

uniform float time;
out vec4 color;

void main()
{
    color = vec4(sin(time)f, sin(time)f, sin(time)f, 1.0f);
}