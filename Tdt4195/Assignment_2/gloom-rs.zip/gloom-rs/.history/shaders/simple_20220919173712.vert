#version 430 core

in layout(location=0) vec3 position;
in layout(location=1) vec4 colors;

out layout(location=1) vec4 rgba;

void main()
{
    // With a negative value the position will flip the shape both horisontally and vertically
    gl_Position = vec4(position, 1.0f);


    float z = (colors.z + 1)*0.5;
    //rgba = Color(new), Colors.rgb = Color(Source), z = Alpha(Source), vec(1.0) = Color(Destination), (1-z) = (1 - Alpha(Source))
    //rgba = vec4(colors.rgb*z + vec3(0.5)*(1-z), colors.a);

    rgba = vec4(colors.rgb*z + vec3(0.9)*(1-z), colors.a);

    //rgba = vec4(colors);
}