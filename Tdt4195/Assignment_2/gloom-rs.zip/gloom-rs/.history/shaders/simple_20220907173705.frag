#version 430 core

uniform float time;
out vec4 color;

void main()
{
    randInt1 = mod(time, 1000) / 1000;
    randInt2 = mod(time, 1000) / 1000;
    randInt3 = mod(time, 1000) / 1000;
    vec3 rand = vec3(randInt1, randInt2, randInt3);
    color = vec4(rand, 1.0f);
}