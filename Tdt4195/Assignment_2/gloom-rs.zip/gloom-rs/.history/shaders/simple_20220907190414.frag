#version 430 core

out vec4 color;
in float Red;
in float Green;
in float Blue;

void main()
{
    float rand = sin(1824) - mod(sin(1824), 0.1);
    color = vec4(0.4f, 0.4f, 0.4f, 1.0f);
}