#version 430 core

out vec4 color;
in int red;
in int green;
in int blue;

void main()
{
    color = vec4(red, green, blue, 1.0f);
}