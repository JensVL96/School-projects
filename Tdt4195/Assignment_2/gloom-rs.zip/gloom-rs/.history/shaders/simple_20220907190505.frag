#version 430 core

out vec4 color;
in float red;
in float green;
in float blue;

void main()
{
    color = vec4((red)f, (green)f, (blue)f, 1.0f);
}