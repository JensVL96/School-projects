#version 430 core

in vec3 position;
out float red;
out float green;
out float blue;

void main()
{
    gl_Position = vec4(position, 1.0f);
}