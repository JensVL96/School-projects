#version 430 core

uniform float time;
out vec4 color;

void main()
{
    float rand = sin(time) - mod(sin(time), 0.1);
    color = vec4(mod(rand, 0.1), rand, rand, 1.0f);
}