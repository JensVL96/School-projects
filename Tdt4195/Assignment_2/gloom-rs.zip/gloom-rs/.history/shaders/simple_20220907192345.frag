#version 430 core

out vec4 color;
in float red;
in float green;
in float blue;

void main()
{
    color = vec4((red)f, greenf, bluef, 1.0f);
}