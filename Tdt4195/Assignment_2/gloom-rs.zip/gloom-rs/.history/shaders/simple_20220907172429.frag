#version 430 core

uniform float time;
out vec4 color;

void main()
{
    vec3 inputs = 
    float rand = random(inputs);
    vec3 temp = vec3(rand);
    color = vec4(temp, 1.0f);
}