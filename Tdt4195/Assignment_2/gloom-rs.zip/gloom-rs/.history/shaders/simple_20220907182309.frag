#version 430 core

uniform float time;
out vec4 color;

void main()
{
    float rand = sin(1823) - mod(sin(1823), 0.1);
    color = vec4(rand, rand, rand, 1.0f);
}