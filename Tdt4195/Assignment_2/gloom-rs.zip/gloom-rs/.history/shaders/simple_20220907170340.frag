#version 430 core

out vec4 color;
#define smooth 1

vec3 rainbow(float level)
{
	float r = float(level <= 2.0) + float(level > 4.0) * 0.5;
	float g = max(1.0 - abs(level - 2.0) * 0.5, 0.0);
	float b = (1.0 - (level - 4.0) * 0.5) * float(level >= 4.0);
	return vec3(r, g, b);
}

vec3 smoothRainbow (float x)
{
    float level1 = floor(x*6.0);
    float level2 = min(6.0, floor(x*6.0) + 1.0);
    
    vec3 a = rainbow(level1);
    vec3 b = rainbow(level2);
    
    return mix(a, b, fract(x*6.0));
}

void main(out vec4 fragColor, in vec2 fragCoord)
{
    vec2 uv = fragcoord.xy / iResolution.xy;

    #if SMOOTH
    vec3 color = smoothRainbow(uv.x);
    #else
    vec3 color = rainbow(floor(uv.x*6.0));
    #endif
	fragColor = vec4(color,1.0);

    // color = vec4(1.0f, 1.0f, 1.0f, 1.0f);
}