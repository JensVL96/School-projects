#version 430 core

uniform float time;
out vec4 color;

void main()
{
    vec3 inputs = vec3(0, 1, time);
    float rand = random(inputs);
    vec3 luma = vec3(rand);
    color = vec4(luma, 1.0f);
}