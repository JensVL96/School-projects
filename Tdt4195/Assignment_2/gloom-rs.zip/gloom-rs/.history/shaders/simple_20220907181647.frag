#version 430 core

uniform float time;
out vec4 color;

void main()
{
    float rand = sin(time)
    color = vec4(rand, randf, randf, 1.0f);
}