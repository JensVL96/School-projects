#version 430 core

out vec4 color;
// uniform layout(location=0) float red;
// uniform layout(location=1) float green;
// uniform layout(location=2) float blue;
in layout(location=1) vec4 colors;

void main()
{
    color = vec4(colors);
}