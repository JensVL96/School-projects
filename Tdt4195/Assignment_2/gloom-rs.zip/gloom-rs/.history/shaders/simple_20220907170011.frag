#version 430 core

out vec4 color;
#define smooth 1

void main(out vec4 fragColor, in vec2 fragCoord)
{
    vec2 uv = fragcoord.xy / iResolution.xy;

    #if SMOOTH
    vec3 color = smoothRainbow(uv.x);
    #else
    vec3 color = rainbow(floor(uv.x*6.0));
    #endif
    
	fragColor = vec4(color,1.0);

    color = vec4(1.0f, 1.0f, 1.0f, 1.0f);
}