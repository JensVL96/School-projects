#version 430 core

out vec4 color;
#define smooth 1

void main()
{
    color = vec4(1.0f, 1.0f, 1.0f, 1.0f);
}