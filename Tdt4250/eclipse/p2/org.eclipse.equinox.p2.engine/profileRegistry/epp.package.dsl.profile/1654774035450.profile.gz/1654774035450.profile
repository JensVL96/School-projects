<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='epp.package.dsl' timestamp='1654774035450'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/jenkins/agent/workspace/simrel.epp-tycho-build/org.eclipse.epp.packages/packages/org.eclipse.epp.package.dsl.product/target/products/epp.package.dsl/linux/gtk/x86_64/eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/jenkins/agent/workspace/simrel.epp-tycho-build/org.eclipse.epp.packages/packages/org.eclipse.epp.package.dsl.product/target/products/epp.package.dsl/linux/gtk/x86_64/eclipse'/>
  </properties>
</profile>
